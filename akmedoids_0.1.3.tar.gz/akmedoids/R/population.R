#' @title sample population (denominator) data
#' @description simulated denominator data for two consecutive census years
#' @name population
#' @docType data
#' @usage population
#' @format A matrix
#' @keywords datasets

NULL
