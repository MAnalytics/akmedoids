
## Test environments
* local OS Windows, R 3.5.3
* Debian Linux (R-devel), R 3.5.3
* win-builder (devel and release), R 3.5.3 


## R CMD check results
There were no ERRORs, WARNINGs or NOTEs. 

##

'Akmedoids' package updated 6th January 2020 (New version: v0.1.3)

### Three major updates:

1. Add arguments 'digits' and 'scale' to the 'props' function. 
2. Add argument 'crit' to the 'akmedoids.clust' function
3. Add new function 'elbowPoint' for determining the elbowpoint on a curve.

Your faithfully.
Monsuru.

