---
title: "NEWS.md"
authors: "geoMADE"
date: "6 January 2020"
output: html_document
---

### R Markdown

'Akmedoids' package updated (Version: v0.1.3)

### Updates:

1. Added arguments 'digits' and 'scale' to the 'props' function. 
2. Added argument 'crit' to the 'akmedoids.clust' function
3. Added new function 'elbowPoint' for determining the elbow point along a curve

Your faithfully.
Monsuru.
